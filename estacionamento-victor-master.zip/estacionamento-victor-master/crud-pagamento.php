<?php
    
    function inclui_Pagamento($conexao,$idrotativo)



?>